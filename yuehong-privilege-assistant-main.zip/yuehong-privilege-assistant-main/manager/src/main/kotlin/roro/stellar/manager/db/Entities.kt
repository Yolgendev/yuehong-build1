package roro.stellar.manager.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "commands")
data class CommandEntity(
    @PrimaryKey val id: String,
    val title: String,
    val command: String,
    val mode: String,
    val enabled: Boolean = true,
    val maxExecutions: Int = 0,
    val executionCount: Int = 0,
    val successCount: Int = 0,
    val failureCount: Int = 0
)

@Entity(tableName = "config")
data class ConfigEntity(
    @PrimaryKey val key: String,
    val value: String
)

@Entity(tableName = "logs")
data class LogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val line: String
)
