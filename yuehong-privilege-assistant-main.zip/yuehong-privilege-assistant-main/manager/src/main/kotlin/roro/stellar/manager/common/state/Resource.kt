package roro.stellar.manager.common.state

enum class Status {
    SUCCESS,
    ERROR
}

data class Resource<out T>(
    val status: Status,
    val data: T?,
    val error: Throwable?
) {
    companion object {
        fun <T> success(data: T?): Resource<T> = Resource(Status.SUCCESS, data, null)

        fun <T> error(error: Throwable, data: T? = null): Resource<T> = Resource(Status.ERROR, data, error)
    }
}

