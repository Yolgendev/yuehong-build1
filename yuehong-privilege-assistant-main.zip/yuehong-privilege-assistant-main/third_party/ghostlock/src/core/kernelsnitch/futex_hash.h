#pragma once

/* Pure hash/bucket arithmetic: no KernelSnitch state, no Android headers, so
 * the same translation unit can be exercised by host fixed-vector tests. */
#include <cerrno>
#include <cstddef>
#include <cstdint>

// --------------- ADDED/REPLACED FOR COMPATIBILITY ---------------
namespace ghostlock::kernelsnitch {
    typedef uint32_t u32;
    typedef uint32_t __u32;
    typedef uint8_t u8;

    // #include <linux/bitops.h>
    static inline __u32 rol32(__u32 word, uint32_t shift) {
        return (word << (shift & 31)) | (word >> ((-shift) & 31));
    }

#define fallthrough __attribute__((fallthrough));
    // --------------- ADDED/REPLACED FOR COMPATIBILITY ---------------

    /* jhash.h: Jenkins hash support.
 *
 * Copyright (C) 2006. Bob Jenkins (bob_jenkins@burtleburtle.net)
 *
 * https://burtleburtle.net/bob/hash/
 *
 * These are the credits from Bob's sources:
 *
 * lookup3.c, by Bob Jenkins, May 2006, Public Domain.
 *
 * These are functions for producing 32-bit hashes for hash table lookup.
 * hashword(), hashlittle(), hashlittle2(), hashbig(), mix(), and final()
 * are externally useful functions.  Routines to test the hash are included
 * if SELF_TEST is defined.  You can use this free for any purpose.  It's in
 * the public domain.  It has no warranty.
 *
 * Copyright (C) 2009-2010 Jozsef Kadlecsik (kadlec@blackhole.kfki.hu)
 *
 * I've modified Bob's hash to be useful in the Linux kernel, and
 * any bugs present are my fault.
 * Jozsef
 */
    // #include <linux/bitops.h>
    // #include <linux/unaligned/packed_struct.h>

    /* Best hash sizes are of power of two */
#define jhash_size(n)   ((u32)1<<(n))
    /* Mask the hash value, i.e (value & jhash_mask(n)) instead of (value % n) */
#define jhash_mask(n)   (jhash_size(n)-1)

    /* __jhash_mix -- mix 3 32-bit values reversibly. */
#define __jhash_mix(a, b, c)            \
{                        \
    (a) -= (c);  (a) ^= rol32((c), 4);  (c) += (b);    \
    (b) -= (a);  (b) ^= rol32((a), 6);  (a) += (c);    \
    (c) -= (b);  (c) ^= rol32((b), 8);  (b) += (a);    \
    (a) -= (c);  (a) ^= rol32((c), 16); (c) += (b);    \
    (b) -= (a);  (b) ^= rol32((a), 19); (a) += (c);    \
    (c) -= (b);  (c) ^= rol32((b), 4);  (b) += (a);    \
}

    /* __jhash_final - final mixing of 3 32-bit values (a,b,c) into c */
#define __jhash_final(a, b, c)            \
{                        \
    (c) ^= (b); (c) -= rol32((b), 14);        \
    (a) ^= (c); (a) -= rol32((c), 11);        \
    (b) ^= (a); (b) -= rol32((a), 25);        \
    (c) ^= (b); (c) -= rol32((b), 16);        \
    (a) ^= (c); (a) -= rol32((c), 4);        \
    (b) ^= (a); (b) -= rol32((a), 14);        \
    (c) ^= (b); (c) -= rol32((b), 24);        \
}

    /* An arbitrary initial parameter */
#define JHASH_INITVAL        0xdeadbeef

    /* jhash - hash an arbitrary key
 * @k: sequence of bytes as key
 * @length: the length of the key
 * @initval: the previous hash, or an arbitray value
 *
 * The generic version, hashes an arbitrary sequence of bytes.
 * No alignment or length assumptions are made about the input key.
 *
 * Returns the hash value of the key. The result depends on endianness.
 */


    /* jhash2 - hash an array of u32's
 * @k: the key which must be an array of u32's
 * @length: the number of u32's in the key
 * @initval: the previous hash, or an arbitray value
 *
 * Returns the hash value of the key.
 */
    static inline u32 jhash2(const u32 *k, u32 length, u32 initval) {
        u32 a, b, c;

        /* Set up the internal state */
        a = b = c = JHASH_INITVAL + (length << 2) + initval;

        /* Handle most of the key */
        while (length > 3) {
            a += k[0];
            b += k[1];
            c += k[2];
            __jhash_mix(a, b, c);
            length -= 3;
            k += 3;
        }

        /* Handle the last 3 u32's: all the case statements fall through */
        switch (length) { // NOLINT(bugprone-switch-missing-default-case): 0..3 is exhaustive
            case 3: c += k[2];
                fallthrough;
            case 2: b += k[1];
                fallthrough;
            case 1: a += k[0];
                __jhash_final(a, b, c);
            case 0: /* Nothing left to add */
                break;
        }

        return c;
    }

    /* __jhash_nwords - hash exactly 3, 2 or 1 word(s) */
    static inline u32 __jhash_nwords(u32 a, u32 b, u32 c, u32 initval) {
        a += initval;
        b += initval;
        c += initval;

        __jhash_final(a, b, c);

        return c;
    }

    static inline u32 jhash_3words(u32 a, u32 b, u32 c, u32 initval) {
        return __jhash_nwords(a, b, c, initval + JHASH_INITVAL + (3 << 2));
    }

    static inline u32 jhash_2words(u32 a, u32 b, u32 initval) {
        return __jhash_nwords(a, b, 0, initval + JHASH_INITVAL + (2 << 2));
    }

    static inline u32 jhash_1word(u32 a, u32 initval) {
        return __jhash_nwords(a, 0, 0, initval + JHASH_INITVAL + (1 << 2));
    }

#define OFFSET_OF(TYPE, FIELD) ((size_t) &((TYPE *)0)->FIELD)

#define FUTEX_KEY_INIT (union futex_key) { .both = { .ptr = 0ULL } }

    typedef union {
        struct {
            uint64_t i_seq;
            unsigned long pgoff;
            uint32_t offset;
        } shared;

        struct {
            union {
                // struct mm_struct *mm;
                void *mm;
                uint64_t __tmp;
            };

            unsigned long address;
            uint32_t offset;
        } private_key;

        struct {
            uint64_t ptr;
            unsigned long word;
            uint32_t offset;
        } both;
    } futex_key_t;

    /* Immutable truncation policy for Linux futex bucket hashing. The kernel table
 * size is always a power of two, so table_size also defines the mask used by
 * futex_hash_context_bucket(). */
    typedef struct futex_hash_context {
        uint32_t table_size;
    } FutexHashContext;

    static_assert(sizeof(FutexHashContext) == sizeof(uint32_t));
    static_assert(alignof(FutexHashContext) == alignof(uint32_t));

    static inline uint32_t futex_hash_no_trunc(futex_key_t *key) {
        uint32_t hash = jhash2(reinterpret_cast<uint32_t *>(key), OFFSET_OF(__typeof__(*key), both.offset) / 4,
            key->both.offset);

        return hash;
    }

    static inline uint32_t __futex_hash(futex_key_t *key, uint32_t futex_hashsize) {
        uint32_t hash = futex_hash_no_trunc(key);

        return hash & (futex_hashsize - 1);
    }

    /* Linux sizes the futex table from the possible CPUs and rounds that up to a
 * power of two (kernel/futex/core.c: roundup_pow_of_two(256 *
 * num_possible_cpus())). Online CPUs fluctuate with hotplug and thermal limits,
 * so deriving the size from them both violates the power-of-two policy and
 * mis-sizes the table. Input: possible CPU count; output: kernel table size. */
    static inline size_t futex_hash_table_size_for(size_t cpu_count) {
        size_t size = (cpu_count ? cpu_count : 1) * 256;
        size_t rounded = 1;
        while (rounded < size)
            rounded <<= 1;
        return rounded;
    }

    /* Initialize an explicit hash context. Inputs: caller-owned context and the
 * target futex table size (futex_hash_table_size_for()); output: 0 or -1 with
 * errno=EINVAL. This validates policy only and performs no allocation or
 * process-global mutation. */
    static inline int32_t futex_hash_context_init(FutexHashContext *context,
                                              size_t table_size) {
        if (!context || table_size == 0 || table_size > UINT32_MAX ||
            (table_size & (table_size - 1)) != 0) {
            errno = EINVAL;
            return -1;
        }
        context->table_size = static_cast<uint32_t>(table_size);
        return 0;
    }

    /* Hash a prepared private/shared futex key with explicit table policy. Input:
 * immutable context and key; output: bucket index, or UINT32_MAX for an invalid
 * context. Jenkins mixing and truncation are intentionally delegated to the
 * unchanged compatibility primitives above. */
    static inline uint32_t
    futex_hash_context_key(const FutexHashContext *context, futex_key_t *key) {
        if (!context || !context->table_size || !key)
            return UINT32_MAX;
        return __futex_hash(key, context->table_size);
    }

    /* Construct the Linux private futex key for address/mm and hash it using only
 * explicit inputs. Input: immutable context, userspace address and candidate
 * mm; output: bucket index, or UINT32_MAX for an invalid context. */
    static inline uint32_t
    futex_hash_context_bucket(const FutexHashContext *context, size_t addr,
                              size_t mm) {
        futex_key_t key = {};
        key.private_key.mm = (void *) mm;
        key.private_key.address = addr & ~static_cast<size_t>(0xfff);
        key.private_key.offset = addr & 0xfff;
        return futex_hash_context_key(context, &key);
    }
} // namespace ghostlock::kernelsnitch
